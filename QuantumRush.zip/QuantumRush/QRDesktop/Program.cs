﻿
using var game = QRLibrary.QuantumRush.Instance();
game.Run();
