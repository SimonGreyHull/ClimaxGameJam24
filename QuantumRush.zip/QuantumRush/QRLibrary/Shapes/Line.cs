﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QRLibrary.Shapes
{
	internal class Line
	{
	}
}
