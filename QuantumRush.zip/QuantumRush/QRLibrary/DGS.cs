﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QRLibrary
{
	internal static class DGS
	{
		public const float SECONDS_TO_DISPLAY_FLASH_SCREEN = 1.5f;
	}
}
